package com.devsuperior.felipe.dominioorm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DominioormApplication {

	public static void main(String[] args) {
		SpringApplication.run(DominioormApplication.class, args);
	}

}
