package com.devsuperior.felipe.dominioorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DominioormApplicationTests {

	@Test
	void contextLoads() {
	}

}
